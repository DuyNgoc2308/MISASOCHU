//slide show------
var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
    showSlides(slideIndex += n);
}

function currentSlide(n) {
    showSlides(slideIndex = n);
}

function showSlides(n) {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    if (n > slides.length) { slideIndex = 1 }
    if (n < 1) { slideIndex = slides.length }
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex - 1].style.display = "block";
    dots[slideIndex - 1].className += " active";
}

//dispplay items------


var items = [{
        image: "images/2.png",
        name: "LIVING ROOM",
        description: "LIVING ROOM LIVING ROOM LIVING ROOM"
    }, {
        image: "images/3.png",
        name: "LIVING ROOM",
        description: "LIVING ROOM LIVING ROOM LIVING ROOM"
    }, {
        image: "images/4.png",
        name: "LIVING ROOM",
        description: "LIVING ROOM LIVING ROOM LIVING ROOM"
    },
    {
        image: "images/5.png",
        name: "LIVING ROOM",
        description: "LIVING ROOM LIVING ROOM LIVING ROOM"
    },
    {
        image: "images/7.png",
        name: "LIVING ROOM",
        description: "LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM"
    },
    {
        image: "images/8.png",
        name: "LIVING ROOM",
        description: "LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM LIVING ROOM"
    }
];
console.log(items);
var livingRoom = [];
displayFourCol(items);
livingRoom = items;
displayTwoCol(items);

function displayFourCol(livingRoom) {
    document.getElementById("grid4-container").innerHTML = ' ';
    for (var i = 0; i < livingRoom.length - 2; i++) {
        var container = document.getElementById("grid4-container");
        var div = document.createElement("div");
        div.className = "card";
        var image = document.createElement("img");
        var name = document.createElement("h3");
        var description = document.createElement("p");
        // description.className = "wrap-text";

        image.src = livingRoom[i].image;
        name.innerHTML = livingRoom[i].name;
        description.innerHTML = livingRoom[i].description;

        div.appendChild(image);
        div.appendChild(name);
        div.appendChild(description);
        container.appendChild(div);
    }
}

function displayTwoCol(livingRoom) {
    document.getElementById("grid2-container").innerHTML = ' ';
    for (var i = livingRoom.length - 2; i < livingRoom.length; i++) {
        var container = document.getElementById("grid2-container");
        var div = document.createElement("div");
        div.className = "card";
        var name = document.createElement("h2");
        var image = document.createElement("img");
        var description = document.createElement("p");
        description.className = "wrap-text";

        image.src = livingRoom[i].image;
        name.innerHTML = livingRoom[i].name;
        description.innerHTML = livingRoom[i].description;

        div.appendChild(name);
        div.appendChild(image);
        div.appendChild(description);
        container.appendChild(div);
    }
}